import java.math.*;
import static java.math.BigDecimal.*;
import static java.math.RoundingMode.*;
public class EX_40 {
	
	public static void main(String[] args) throws Exception{
		BigDecimal bd1 = new BigDecimal("123.456");
		BigDecimal bd2 = new BigDecimal("1.0");
		
		System.out.println(bd1.divide(bd2, 1, HALF_UP));
		System.out.println();
		System.out.println();
		System.out.println(bd1.divide(bd2, new MathContext(1,HALF_UP)));
		System.out.println(bd1.divide(bd2, new MathContext(2,HALF_UP)));
		System.out.println(bd1.divide(bd2, new MathContext(3,HALF_UP)));
		System.out.println(bd1.divide(bd2, new MathContext(4,HALF_UP)));
		System.out.println(bd1.divide(bd2, new MathContext(5,HALF_UP)));
		System.out.println(bd1.divide(bd2, new MathContext(6,HALF_UP)));
	}

}

