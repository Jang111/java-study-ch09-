import java.util.*;
import java.io.*;
public class EX_34 {
	
	public static void main(String[] args) throws Exception{
		Scanner sc = new Scanner(new File("D:\\data1.txt"));
		int cnt = 0;
		int totalsum =0;
		
		while(sc.hasNextLine()) {
			String line = sc.nextLine();
			Scanner sc2 = new Scanner(line).useDelimiter(",");
			int sum=0;
			while(sc2.hasNextInt()) {
				sum+=sc2.nextInt();
			}
			System.out.println(line+", sum = "+sum);
			cnt++;
			totalsum+=sum;
		}
		System.out.println("Line : "+cnt+", Total : "+totalsum);
	}

}

