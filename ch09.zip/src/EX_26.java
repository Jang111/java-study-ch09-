import java.util.*;

public class EX_26 {

	public static void main(String[] args){
		
		Random rand = new Random();
		int[] number = new int[100];
		int[] counter = new int[10];
		
		for(int i=0;i<number.length;i++) {
			number[i] = rand.nextInt(10);
			System.out.print(number[i]);
		}
		System.out.println();
		
		for(int i=0;i<number.length;i++) {
			counter[number[i]]++;
		}
		
		for(int i=0;i<counter.length;i++) {
			System.out.println(i+"�� ���� : "+printGraph('#',counter[i])+" "+counter[i]);
		}
	}
	public static String printGraph(char c, int val) {
		char[] bar = new char[val];
		
		for(int i=0;i<bar.length;i++) {
			bar[i] = c;
		}
		return new String(bar);
	}
}

