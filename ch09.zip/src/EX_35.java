import java.util.*;

public class EX_35 {
	
	public static void main(String[] args) throws Exception{
		String source="100,200,300,400";
		StringTokenizer st = new StringTokenizer(source,",",false);
		
		while(st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}
	}

}

