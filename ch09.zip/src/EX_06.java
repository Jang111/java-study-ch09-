import java.util.Objects;

class Card1{
	String kind;
	int number;
	
	Card1(){
		this("SPADE",1);
	}
	Card1(String kind, int number){
		this.kind = kind;
		this.number = number;
	}

	public int hashCode() {
		return Objects.hash(kind,number);
	}
	public boolean equals(Object obj) {
		if(!(obj instanceof Card1)) {
			return false;
		}
		Card1 c = (Card1)obj;
		return this.kind.equals(c.kind) && this.number == c.number;
	}
	public String toString() {
		return "kind : "+kind+", number : "+number;
	}
}
public class EX_06 {

	public static void main(String[] args) {
		Card1 c1 = new Card1();
		Card1 c2 = new Card1();
		System.out.println(c1.equals(c2));
		System.out.println(c1.hashCode());
		System.out.println(c2.hashCode());
		
		System.out.println(c1.toString());
		System.out.println(c2.toString());
	}

}

